<?php
$a=array('ram','rahul','joshi','sharma');
print(count($a));
?>