<?php
$ages['ashish']="12";
$ages['rahul']="20";
$ages['rohit']="24";
echo"rohit is".$ages['rohit']."years old"."<br>";
echo"rahul is".$ages['rahul']."years old";
?>