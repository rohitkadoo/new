<?php
$color=array('red','blue','green');
foreach($color as $co)
{
echo"do you like $co?.<br>";
}
?>