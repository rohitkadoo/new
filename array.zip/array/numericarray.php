<?php
$c[0]="ram";
$c[1]="shyam";
$c[2]="ramesh";
$c[3]="rahul";
echo $c[0] . " and ". $c[1]. " is student" . "<br>";
echo $c[2] . " and " . $c[3] ." are employee";
?>