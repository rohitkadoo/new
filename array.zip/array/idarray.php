<?php
$a=array('ROHIT','KADOO','PHP');
print_r($a);
?>