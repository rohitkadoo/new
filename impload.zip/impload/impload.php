<?php
$arr = array('hi','hello','amit','rahul!');
echo implode(" ",$arr);
?>