<?php
$str = "helo my name is khan. It's a nic.";
print_r (explode(" ",$str));
?>